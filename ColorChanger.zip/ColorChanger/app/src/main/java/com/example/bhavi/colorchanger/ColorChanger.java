package com.example.bhavi.colorchanger;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.Random;

public class ColorChanger extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_changer);
    }

    public void button(View view){
        EditText t = (EditText) findViewById(R.id.editText);
        Random random = new Random();
        int r = random.nextInt(255);
        int g = random.nextInt(255);
        int b = random.nextInt(255);
        t.setTextColor(Color.rgb(r, g, b));
        EditText t2 = (EditText) findViewById(R.id.editText2);
        t2.setText("Color: " + r + "r, " + g + "g, " + b + "b, " + "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b) );

    }

    public void secondActivity(View view){
        Intent secondActivity = new Intent(this, Paint.class);
        startActivity(secondActivity);
    }
}
